
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FastCollinearPoints {

    private final ArrayList<LineSegment> segments;

    /**
     * finds all line segments containing 4 or more points
     *
     * @param points
     */
    public FastCollinearPoints(Point[] points) {
        ArrayList<Point> list = new ArrayList<>(points.length);
        for (Point p : points) {
            if (list.contains(p)) {
                throw new IllegalArgumentException();
            }
            list.add(p);
        }
        segments = calculate(list);
    }

    /**
     * the number of line segments
     *
     * @return
     */
    public int numberOfSegments() {
        return segments.size();
    }

    /**
     * the line segments
     *
     * @return
     */
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[segments.size()]);
    }

    /**
     *
     */
    private ArrayList<LineSegment> calculate(List<Point> points) {
        ArrayList<LineSegment> segmentList = new ArrayList<>();

        Point[] pointsBySlope = new Point[points.size()];
        points.toArray(pointsBySlope);

        double currentSlope, lastSlope = 0;
        int slopeSeen;
        LineSegment segment;

        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);
            slopeSeen = 0;
            Arrays.sort(pointsBySlope, p.slopeOrder());
            for (int j = 0; j < pointsBySlope.length; j++) {
                Point s = pointsBySlope[j];
                if (p.compareTo(s) == 0) {
                    continue;
                }
                currentSlope = p.slopeTo(s);

                // had a chance to see another slope
                if (j > 0) {
                    if (currentSlope == lastSlope) {
                        slopeSeen++;

                        if (j + 1 == pointsBySlope.length && slopeSeen > 2) {
                            segment = createSegment(pointsBySlope, p, j + 1 - slopeSeen, j);
                            if (segment != null) {
                                segmentList.add(segment);
                            }
                        }
                        continue;

                    } else if (slopeSeen > 2) {
                        segment = createSegment(pointsBySlope, p, j - slopeSeen, j - 1);
                        if (segment != null) {
                            segmentList.add(segment);
                        }
                    }
                }

                lastSlope = currentSlope;
                slopeSeen = 1;
            }
        }
        return segmentList;
    }

    private LineSegment createSegment(Point[] source, Point base, int from, int to) {
        //to (exclusive)
        Arrays.sort(source, from, to + 1);
        //we are analyzing the edge point
        if (base.compareTo(source[from]) < 0) {
            return new LineSegment(base, source[to]);
        } else {
            return null;
        }
    }
}
